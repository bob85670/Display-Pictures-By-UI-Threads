package hk.hkucs.thread

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.Button
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import java.io.InputStream
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    var Button1: Button? = null
    var Button2: Button? = null
    var Button3: Button? = null
    var Button4: Button? = null
    var ImageView1: ImageView? = null

    private fun loadImageFromNetwork(url: String): Bitmap? {
        try {
            return BitmapFactory.decodeStream(URL(url).content as InputStream)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        ImageView1 = findViewById<View>(R.id.ImageView1) as ImageView
        Button1 = findViewById<Button>(R.id.button1)
        Button2 = findViewById<Button>(R.id.button2)
        Button3 = findViewById<Button>(R.id.button3)
        Button4 = findViewById<Button>(R.id.button4)
        Button1!!.setOnClickListener {
            val b = loadImageFromNetwork("https://i.cs.hku.hk/~twchim/c3330/android.png")
            ImageView1!!.setImageBitmap(b)
        }
        Button2!!.setOnClickListener {
            Thread {
                val bitmap =
                    loadImageFromNetwork("https://i.cs.hku.hk/~twchim/c3330/android.png")
                ImageView1!!.setImageBitmap(bitmap)
            }.start()
        }
        Button3!!.setOnClickListener {
            Thread {
                val bitmap =
                    loadImageFromNetwork("https://i.cs.hku.hk/~twchim/c3330/android.png")
                ImageView1!!.post { ImageView1!!.setImageBitmap(bitmap) }
            }.start()
        }
        Button4!!.setOnClickListener {
            val executor = Executors.newSingleThreadExecutor()
            val handler = Handler(Looper.getMainLooper())
            executor.execute {
                val bitmap =
                    loadImageFromNetwork("https://i.cs.hku.hk/~twchim/c3330/android.png")
                handler.post { ImageView1!!.setImageBitmap(bitmap) }
            }
        }
    }
}